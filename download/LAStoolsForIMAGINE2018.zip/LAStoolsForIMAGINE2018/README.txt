Installation instructions can be found in the file "LAStools_for_IMAGINE_Installation_Guide.pdf" located in the Docs folder of this installation.
